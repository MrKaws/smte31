//
//  GlowAct.h
//  HellGlow World
//
//  Created by Anh Tran on 13-02-14.
//  Copyright (c) 2014 Anh Tran. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface GlowAct : NSObject

@property NSString* name;
@property NSInteger rating;
@property NSString* startTime;


-(void)showOff;

@end
