//
//  XYZAppDelegate.h
//  ToDoList
//
//  Created by Anh Tran on 17-02-14.
//  Copyright (c) 2014 Anh Tran. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYZAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
