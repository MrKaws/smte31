//
//  main.m
//  ToDoList
//
//  Created by Anh Tran on 17-02-14.
//  Copyright (c) 2014 Anh Tran. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "XYZAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([XYZAppDelegate class]));
    }
}
